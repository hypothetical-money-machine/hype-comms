# Cache retention during older-history loading

A recent populated cache no longer requires fetching and sorting every encrypted message after
each history page. The first unprofiled candidate reduced the 550 → 600-message older-history
action from 826 ms to 342 ms. It followed the same 11 history pages and 11 reaction queries and
retained the same 1,552 specifically checked message IDs. An independent repeat took 333 ms.

## Profile and change

The [profiled control](improved-2026-09-06/eviction-profile.json) took 831 ms for the action.
CDP reported 435 ms of renderer task time, 146 ms of script time, 3.1 ms of layout and 1.4 ms of
style recalculation. The 22 server responses summed to 67.4 ms of handler time. These are different
measurements with overlapping work; they must not be added together or treated as a complete
breakdown of elapsed time.

The local `older-history.cpuprofile` in
`.dev-data/performance/2026-09-06T10-42-55-362Z-older-history-profile/` showed about 51 ms of inclusive
JavaScript samples in `#evictMessages`, 79 ms in an IndexedDB result callback and 53 ms in garbage
collection. The source fetched and sorted the entire messages table after each history page,
repeating that work 11 times over roughly 11,700 encrypted rows. Callback and garbage-collection
samples also include other work; this profile does not attribute all of them to retention.

`PersistentWorkspaceCache.#evictMessages` now reads the count and first `createdAt` index key in
one read-only transaction. It skips the full scan when the table is empty, or when the count is
at most 20,000 and the earliest indexed minute is newer than the 90-day cutoff minute. The index
already exists, so this adds no schema migration.

Wire timestamps are UTC but can have different precision. A minute-only timestamp can sort after
a newer timestamp containing seconds within the same minute. Comparing minute prefixes avoids
mistaking that newer index entry for proof that every row is recent. When the count exceeds the
cap, or the oldest minute is at or before the cutoff minute, the original full scan, stable sort,
exact age comparison, message deletion and reaction cleanup run unchanged. This retains the
existing boundary and tie behavior. It does not make eviction cheaper when eviction is needed.

## Native comparison

The [unprofiled control](improved-2026-09-06/eviction-control.json) and
[candidate](improved-2026-09-06/eviction-candidate.json) and
[independent repeat](improved-2026-09-06/eviction-repeat.json) used 200 channels, five fresh/restored
startup pairs, 20 interaction samples, a populated cache and five 300-message backlog cycles.
Runs execute sequentially against isolated PostgreSQL and synthetic users in the unpackaged macOS
Electron app. The older-history action runs once at the end of each complete run; these action
values are observations, not percentiles. Profiling was disabled in all three compared runs.

| Observation                                    |   Control | Candidate |    Repeat |
| ---------------------------------------------- | --------: | --------: | --------: |
| Older-history action                           |    826 ms |    342 ms |    333 ms |
| Renderer script duration during action         |    137 ms |     45 ms |     43 ms |
| Renderer task duration during action           |    382 ms |    116 ms |    117 ms |
| Server response count                          |        22 |        22 |        22 |
| Summed server handler duration                 |   60.5 ms |   44.6 ms |   43.4 ms |
| Design rows before/after action                | 550 → 600 | 550 → 600 | 550 → 600 |
| Final durable message count                    |    11,744 |    11,744 |    11,744 |
| Specifically checked durable IDs               |     1,552 |     1,552 |     1,552 |
| Fresh content, median                          |  1,227 ms |  1,214 ms |  1,227 ms |
| Populated-cache restored content, median       |    683 ms |    615 ms |    618 ms |
| Populated-cache restored realtime live, median |    841 ms |    758 ms |    768 ms |
| Backlog content, median                        |    659 ms |    667 ms |    714 ms |
| Backlog realtime live, median                  |  1,508 ms |  1,547 ms |  1,611 ms |
| Cached switch, p95                             |   50.9 ms |   49.2 ms |   49.1 ms |
| Composer → recipient, p95                      |   77.1 ms |   63.8 ms |   62.7 ms |
| Search submit → results, driver p95            |  111.9 ms |  112.3 ms |  112.3 ms |

Both candidate actions were about 59–60% shorter and renderer task time fell about 69–70%.
Handler times also varied, but their 16–17 ms difference is small relative to the 484–494 ms elapsed
reduction. Backlog content and live medians increased in both candidate runs, by up to 55 and
103 ms respectively. This change does not establish a catch-up speedup or rule out a regression
there. Those results remain within the 750 ms content and 2,000 ms live planning budgets.
Typing stayed near the two-frame measurement floor, with the final 550-row cycle at 33.3–33.4 ms
median across the runs. The remaining roughly one-third-second history wait still warrants work, especially
on connections with latency across the sequential page requests.

## Reverse-order control

A later [control repeat](improved-2026-09-06/eviction-reversed-control.json) temporarily removed only
the indexed preflight and ran the same 200-channel, five-cycle scenario after both candidates.
The runner restored the indexed source in a `finally` block and verified its original bytes.
Older-history loading returned to 842 ms, with 382 ms renderer task time, the same 22 responses,
and all 1,552 final IDs. This supports retaining the older-history improvement across run order.

The repeated control's backlog medians were 669 ms content and 1,535 ms live, compared with
659/1,508 ms in the first control and 667/1,547 ms and 714/1,611 ms in the two candidates.
Those startup differences remain inconclusive. The candidate's 333–342 ms older-history time
must not be used as evidence that restart catch-up improved. The current nonempty catch-up path
still reloads every cached conversation; a separate profiling probe will measure those reads.

## Correctness and evidence

Three new retention tests cover avoiding unrelated encrypted-value reads on recent history,
mixed-precision expiry with exact boundary retention, reaction cleanup, outbox preservation, and
20,002 input messages reduced to the existing 20,000 cap with the same ID tie behavior. The cap test
also checks a subsequent refresh at exactly the cap skips the full scan. All 281 targeted cache,
conformance and runtime tests passed, as did desktop typechecking and lint. The first test run
failed because its fixture tried enqueueing before authorizing a snapshot. The corrected fixture
initializes the snapshot and asserts enqueue succeeds; the authorization guard was preserved.

Both native candidates traversed all 1,500 cumulative generated backlog bodies, then all 600 Design
IDs after the older-history action. Each verified the 50 newly fetched IDs and both layout-check
messages in the encrypted cache. Each also rendered all 81 paragraphs of the tall-message check,
kept the tail attached, and preserved the reading anchor during an off-tail incoming message.
These checks do not establish prepend anchoring, normal visible-read behavior, packaged performance,
or behavior on other operating systems. No wire, authentication, encryption or retention policy
changed.

![Design after loading older history with indexed retention](../screenshots/performance-indexed-retention.png)

The screenshot comes from the completed candidate and was visually inspected. It shows the newly
loaded synthetic history beginning at Design item 101. Raw JSON copies preserve their original
content; the initial baseline report and four baseline JSONs remain unchanged.

Reproduce with the environment in [README](README.md):

```sh
npm run perf:baseline -- --label=eviction-repeat --channels=200 --samples=5 \
  --iterations=20 --restore-cache=all --backlog=300
```

The full `npm run check` passed formatting, lint, typechecking, all workspace builds and tests:
1,888 desktop, 194 default server, 145 CLI, 150 contracts, 186 script and 113 Hermes plugin tests.
The suite skips 230 opt-in PostgreSQL tests and one optional Docker test; the native benchmarks
separately exercised real PostgreSQL. The check log is
`.dev-data/performance/check-indexed-retention.log`. The final independent review was configured
as `gpt-5.6-terra` and found no substantive attention flags. The evidence audit also verified JSON
copies, screenshot provenance and all nine current benchmark script hashes plus the lockfile.
The broader performance goal remains active; no package, commit or pull request was produced.
