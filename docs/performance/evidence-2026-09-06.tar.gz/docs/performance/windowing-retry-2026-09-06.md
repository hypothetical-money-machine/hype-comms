# Windowing retry

The second Virtuoso experiment was rejected. A visible-row timer measured 328–358 ms first visits
in its completed diagnostic run, above the 100 ms target. Two large runs also failed search
centering. App, CSS, read tracking, the desktop manifest and lockfile were restored byte-for-byte
from the pre-experiment backup. No virtual component or dependency remains in the application.
The branch keeps the preceding startup, cache, rendering, query and scroll corrections.

The experiment limited mounted rows after a conversation exceeded 200 canonical and pending
messages, then kept the same scroller until that conversation unmounted. Short histories retained
the regular layout. Its source and temporary diagnostics remain in the ignored
`.dev-data/performance/rejected-windowing-retry/` directory for inspection, not as an accepted design.

The current scroll corrections provide the control for this retry. The earlier virtual timeline's
32.375 px prepend failure remains in the [original investigation](windowing-2026-09-06.md).

## Behavior and measurement corrections

The [first retry](improved-2026-09-06/windowing-retry-traversal-failed.json) stopped during full-history
traversal with 165 of 208 IDs observed. Its third older-history action crossed the windowing threshold.
The traversal now uses the existing repeated scroll-to-top helper before enumerating all loaded rows,
so an outstanding history layout correction cannot supersede its first scroll assignment. The
complete-count and exact backlog-body checks remain in force.

The [next retry](improved-2026-09-06/windowing-retry-reading-failed.json) traversed every backlog body,
then reported a 37 px tall-message reading shift. A generic before-update snapshot did not change
that result in the [snapshot retry](improved-2026-09-06/windowing-retry-snapshot-failed.json).
The subsequent [diagnostic run](improved-2026-09-06/windowing-retry-trace.json) and its
[geometry trace](improved-2026-09-06/windowing-retry-reading-trace.json) showed that most of the
movement occurred before the incoming-message call. The old paragraph-top sample was 317.602 px;
a later geometry sample taken before sending already put its containing article at 324.906 px.
After the send, that article was at 325.102 px with unchanged scrollTop. The trace's snapshot and
correction events likewise observed no substantial movement during the send.

The probe now samples paragraph position synchronously in the same browser evaluation immediately
before calling the real message-send IPC. It still waits for message-count growth and checks that
the paragraph moves no more than 1 px, retaining before/after geometry. The generic snapshot and
its temporary renderer events were removed. This corrects attribution of the incoming-message
check; it does not establish that virtual scrolling never shifts while settling after a jump.

The [complete small run](improved-2026-09-06/windowing-retry-behavior-pass.json) passed the corrected
incoming check with a 0.195 px shift. Search placement, unread entry, initial tail, queued sends and
canonical acknowledgements passed. Prepending another real older page moved the visible message
by −0.125 px, within the 2 px tolerance. The final cache retained 1,479 rows and all 1,071 checked IDs,
including all 1,000 backlog messages. The 81-paragraph message remained readable from beginning to end.
These are single-fixture correctness observations, not latency distributions.

Independent review found two threshold/navigation problems during development. A 201-to-200 removal
could replace the virtual scroller; retaining the mode until unmount fixes that transition and has a
component regression. A history anchor from the previous conversation could override the new unread
target; both initial placement and correction now reject anchors from another conversation. Its
component regression opens at unread history despite the stale anchor. Normal and virtual layouts
share handled focus requests, preserving repeated explicit jumps without replaying a past search
when history grows. Full loaded message order remains the basis of read progression, so unmounted
unread rows cannot be skipped.

## Performance work

The complete small run's backlog content time was 832 ms, compared with 630 ms in the retained small
control. That regression prevents accepting this version. Inspection of the library found that an
object initial target, including `{ index: 0, align: "center" }`, invokes delayed initial scrolling
and keeps rows hidden while it settles. A later candidate used numeric `0` when the opening target was the first row, matching the regular
timeline's top position. Other targets kept centered or tail placement. That change reduced
opening-history startup costs, but did not establish fast visits at other initial positions.

The first-viewport timer now also requires computed visibility to be `visible`. Bounds alone could
count a hidden virtual row. Earlier virtual visit timings cannot establish visible-content speed;
none is claimed here. Complete history traversal still verifies every loaded ID and every synthetic
backlog body separately after all three first visits have been timed.

The [numeric-zero large run](improved-2026-09-06/windowing-top-large-failed.json) stopped at a
70.691 px search-center error: the target was visible, but the viewport center line fell outside
its row. A [second large run](improved-2026-09-06/windowing-focus-large-failed.json) tried centering
the actual DOM row in the library's scroll-completion callback and failed with the same error.
Both runs used 200 channels, five startup pairs, 20 interactions and five 300-message restart batches.
Their final status remains failed; completed timing cycles do not imply passing behavior checks.

A [smaller diagnostic repeat](improved-2026-09-06/windowing-focus-trace.json) used five channels,
three startup pairs, three interactions and three batches of 500 messages. It completed the
behavior suite, but its [focus events](improved-2026-09-06/windowing-focus-events.json) showed the
completion callback running 59.5 ms after the request with `rowExists: false`. That callback could
not center the actual row. The small fixture happened to pass search placement through the library's
own positioning, which did not establish correctness for the two failed large runs.

| Diagnostic cycle | Design loaded rows | Design visible viewport | Performance 004 loaded rows | Performance 004 visible viewport |
| ---------------- | -----------------: | ----------------------: | --------------------------: | -------------------------------: |
| 1                |                217 |                328.1 ms |                         216 |                         337.9 ms |
| 2                |                384 |                340.8 ms |                         382 |                         357.5 ms |
| 3                |                551 |                338.9 ms |                         548 |                         344.5 ms |

Those times include the new visibility predicate. The retained 200-channel renderer's preceding
550-row visits were about 100–105 ms. The diagnostic fixture has fewer channels and different
backlog batches, so it is not a matched speedup comparison. Its values exceed the target by enough
to reject it without claiming a precise regression ratio. The completed run retained 2,011 cache
rows and all 1,603 checked IDs, including 1,500 backlog messages. Its prepend shift was −0.125 px,
and pending/canonical reading shifts were zero. Passing those checks does not offset the latency
and large-run navigation failures.

Component/read-tracking/composer checks, typechecking and lint passed during candidate development.
A later request-cancellation regression failed before a current-focus guard and passed after it.
Those candidate tests and fixes were archived with the implementation. Native evidence controls
acceptance; none of the unit checks established a windowing speedup or cured the large search failure.

## Retained changes and verification

Only the benchmark changes remain from this investigation. In addition to visible-row timing,
settled traversal and the send-boundary measurement, each completed backlog timing cycle now writes
`backlog-progress.json` with `status: "partial"`. A later behavior failure can no longer erase all
per-visit diagnostic timings. That checkpoint is not completion evidence; only the final
`results.json`, durable checks and behavior results can establish a complete run.

The [restored large control](improved-2026-09-06/windowing-retry-retained.json) completed five startup
pairs, 20 interactions and five 300-message backlog cycles with 200 channels. It uses all the
corrected probes. Fresh-content median was 1,217 ms, restored-content median 654 ms, backlog-content
median 674 ms and backlog live-readiness median 1,249 ms. Final first visits took 103.8 ms for Design
and 98.3 ms for Performance 004, each with 550 loaded messages. The initial General visit took
42.7 ms with 742 loaded messages. These values verify the restored renderer; no new application
speedup is claimed from the rejected experiment.

The first older-history action grew Design from 550 to 600 messages in 351 ms. The later prepend
shifted the anchor by 0.125 px. Search center error was 0.176 px with the center line inside the row.
Unread placement, initial tail and pending/canonical transitions passed; the tall-message incoming
check and queued/canonical off-tail checks measured zero shift. Final storage contained 11,796
rows and all 1,604 checked IDs, including all 1,500 cumulative backlog bodies verified by traversal.
The saved [partial checkpoint](improved-2026-09-06/windowing-retry-retained-progress.json) has five
cycles and matches every final per-visit measurement. Its raw source is `backlog-progress.json`,
not the separate `window-behavior-progress.json`. It remains labeled partial because it precedes
the last behavior and durable checks.

![Restored renderer after loading older history](../screenshots/performance-windowing-retry-retained.png)

The real desktop after the retained control's prepend, captured and visually inspected.

The full repository check completed with exit 0: format, lint, typecheck and builds passed,
as did 1,898 desktop, 194 server, 145 CLI and 150 contracts tests. The server suite skipped
230 opt-in tests; this check does not establish those database/integration lanes. First visits to long histories remain open, as do normal
visible read tracking, packaged-app performance and broader workloads. A future rendering approach must produce the correct initial viewport without a long
hidden initialization phase and must pass the existing search, prepend, unread, tall-message and
pending/canonical checks. Do not restore an archived App wholesale; preserve current production changes when investigating
a replacement.
