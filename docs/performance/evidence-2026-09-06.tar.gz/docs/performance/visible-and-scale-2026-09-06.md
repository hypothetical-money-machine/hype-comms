# Visible measurement and larger server histories

A new 200-channel run with 200,008 server messages exposes a search delay that the earlier
40,008-message fixture did not. Search results appeared in 147 ms at p95 on the renderer clock;
the captured SQL query took 131 ms. Startup, cached switching and message delivery stayed within
the existing planning targets. This is a larger-workload baseline on the improved application,
not a new application speedup.

The visible-window pilot produced no valid timings. The computer-use tool reported that the Mac
was locked, and the pilot's browser closed before workspace readiness. The exact cause of that
browser closure was not established. Unlocking the Mac is required before a valid foreground run.
The normal visible read-tracking path remains unverified.

## Larger server history

The [complete run](improved-2026-09-06/large-server-history.json) used the current application,
200 channels with 1,000 generated messages each, two synthetic members, three measured startup
pairs and 20 samples per repeated interaction. One startup and one interaction warmup were excluded.
Every fresh profile visited all channels before restart, retaining 10,000 encrypted cached messages.
There was no offline backlog. The app was production-built, unpackaged, hidden Electron on macOS
arm64 with PostgreSQL 17 on localhost. No tests or builds ran alongside its timed operations.

| Measurement                                       |           Result |
| ------------------------------------------------- | ---------------: |
| Fresh content, median                             |         1,214 ms |
| Fresh realtime live, median                       |         1,215 ms |
| Restored content, median                          |           663 ms |
| Restored realtime live, median                    |           863 ms |
| Fresh HTTP responses                              |    14 per launch |
| First Design visit after restart, one observation |          61.4 ms |
| Cached conversation switch, p95                   |          51.0 ms |
| Composer to recipient, p95                        |          78.5 ms |
| Composer local feedback, p95                      |          46.0 ms |
| Typing through two frames, p95                    |          33.8 ms |
| Search result DOM mutation, median / p95          | 142.5 / 147.0 ms |
| Search browser two-frame checkpoint, median / p95 | 145.8 / 161.9 ms |
| Search driver timing, median / p95                | 196.0 / 212.9 ms |
| Search HTTP during UI loop, median                |         140.0 ms |
| Bootstrap IPC, median                             |          44.5 ms |

The restored cache contained 10,000 message rows, and no unexpected HTTP errors occurred.
The three older-history actions added 50 rows each (92→142→192→242), taking 92.9, 95.1 and 101.4 ms.
This run increases server search history; it does not establish behavior with 200,000 messages
mounted or cached in the renderer, or replace the separate 550-row first-visit/backlog evidence.
It also retains the homogeneous synthetic Markdown workload. Threads, attachments, larger member
sets, WAN behavior and packaged/visible-app performance remain separate evidence gaps.

The query plan ranks 200,000 matching messages, then retains a 26-row page with a 28 KiB top-N
sort. It writes no temporary blocks. Most elapsed query time is before the page limit; fetching
26 full message bodies through the ID index is small. The earlier narrow-sort change still avoids
a spill, but it does not avoid ranking every match for a common search term.

The renderer-clock search p95 exceeds the 100 ms planning target on this workload. Driver polling
still adds delay, but it cannot explain away the 147 ms result-row observation. A useful next target
is to bring common-term search below 100 ms on this fixture while preserving ranking, cursor order
and access filtering. The first step is query profiling and a matched candidate/control comparison.
No result truncation or relevance change is authorized by this performance target.

![Search after the larger-history timing loop](../screenshots/performance-large-server-history-search.png)

The actual Electron search dialog after the timed loop, captured and visually inspected. It shows
results from the 1,000-message-per-channel fixture; this hidden-window screenshot is not evidence of
foreground presentation.

Reproduce with:

```sh
npm run perf:baseline -- --channels=200 --messages=1000 --samples=3 --iterations=20 \
  --restore-cache=all --explain-search=true --label=large-server-history
```

## Query-shape diagnostic

A [read-only diagnostic](improved-2026-09-06/search-materialization-diagnostic.json) restarted only
the runner's isolated database after the native run ended. It compared the current materialized
conversation-access CTE with an inlined CTE and an array-membership filter. Each returned the same
first-page IDs and rank strings on this fixture. Five sequential EXPLAIN ANALYZE observations per
shape had medians of 150.2, 149.1 and 152.9 ms respectively. There is no useful improvement to retain.
No production SQL changed.

These grouped, single-session observations are diagnostic. They are not a randomized performance
comparison, a permission/cursor regression suite, or proof that the shapes are interchangeable.
Their timings also differ from the native run's 130.8 ms captured plan and must not be treated as
an application regression. The reproducible local script is
`.dev-data/performance/compare-search-materialization.mjs`; the raw plans contain each SQL variant.
The first diagnostic attempt used PostgreSQL's default startup port and failed to connect to the
intended port; cleanup stopped that isolated process. The retry pinned the original loopback port
and disabled Unix sockets, then completed and stopped the cluster.

## Visible-window probe

The new `--presentation=visible` mode keeps the primary client non-headless, checks native and DOM
focus/visibility, asserts a 1280×800 content area, records pixel ratio and rejects any later observed
blur or hidden event. The second client stays headless. First visits and timed interaction groups
are bracketed by foreground checks. Different pixel ratios require separate comparison series.

Monitoring begins after window creation and sizing. Startup records its offset as
`presentation.foregroundObservationStartMs` and records the subsequent content wait as
`foregroundReadyMs`. The usual launch-to-content `readyMs` includes an earlier unobserved interval;
it cannot prove foreground presentation throughout process startup.

After timed composer sends, a separate probe delivers a message from the second client, finds its
canonical row, traverses the primary timeline and requires the server read cursor to reach that
message. It rereads bootstrap through production IPC and requires a successful HTTP read-cursor
PUT. It does not directly write read state, bypass headless restrictions or replace focus events.
It is an untimed correctness check. The existing outgoing-delivery timings still end at the hidden
second client. Visible backlog is rejected until that lane's focus ownership and unread setup are
adapted and verified.

The [failed pilot](improved-2026-09-06/visible-pilot-failed.json) has empty startup and metric arrays.
It predates the later persistent foreground-event guard and startup observation offset. The
[hidden control](improved-2026-09-06/visible-mode-hidden-control.json) completed with one startup pair
and three interaction samples. That control and the larger-history run verify the default hidden
path after adding the option; they do not validate the visible path. Native visible validation and
its screenshot remain pending an unlocked Mac.

Formatting and ESLint passed for both changed runner files. Script tests passed 186 tests, with
one optional Docker test skipped (`.dev-data/performance/check-visible-scripts.log`). These tests do
not exercise the visible probe. The preceding full repository check passed on the unchanged
production source, as documented in the [windowing retry report](windowing-retry-2026-09-06.md).
No production implementation changes were made during this measurement work. The full performance
goal remains open.

Independent review by gpt-5.6-terra verified the raw-copy equality, reported measurements, foreground
observation bounds and decision trail. Visible/native, backlog and broader workload limitations
remain as stated above.
