# Search ranking within one access snapshot

Search result-row p95 on the 200,008-message fixture fell from 147 ms to 69 ms and 82 ms in two
native runs. Both retained runs reached the browser's two-frame checkpoint below 100 ms. The
repository now resolves conversation access before ranking messages, using one read-only,
repeatable-read transaction for both queries. PostgreSQL can then rank matching messages in parallel.
Ranking, cursor ordering and access filtering are unchanged.

This is a single-client, hidden-window result on the reference Mac. Concurrent queries, unavailable
parallel workers and system load reduce the benefit. The broader performance goal remains open.

## Native results

Each large run used 200 channels, 1,000 generated messages per channel, two synthetic members,
three measured fresh/restored startup pairs and 20 measured samples per repeated interaction.
Fresh profiles visited every channel before restart and retained 10,000 encrypted cached messages.
There was no offline backlog. Startup and interaction warmups were excluded. Builds and tests ran
separately from benchmarks.

The [before run](improved-2026-09-06/large-server-history.json) came from the preceding scale
investigation. The [first retained run](improved-2026-09-06/search-snapshot-large.json) and
[independent repeat](improved-2026-09-06/search-snapshot-large-repeat.json) use the new transaction.
The [later control](improved-2026-09-06/search-snapshot-control-repeat.json) temporarily restored the
preceding repository source, then restored the candidate byte-for-byte in a `finally` block.
That control used the same runner as the retained runs, including the updated SQL-plan capture.

| Measurement                    |   Before | Retained | Retained repeat | Later control |
| ------------------------------ | -------: | -------: | --------------: | ------------: |
| Search result-row p95          | 147.0 ms |  69.2 ms |         82.3 ms |      410.9 ms |
| Search browser two-frame p95   | 161.9 ms |  79.3 ms |         94.9 ms |      429.3 ms |
| Legacy search driver p95       | 212.9 ms | 114.7 ms |        211.2 ms |      831.5 ms |
| Search IPC median (50 results) | 136.1 ms |  67.7 ms |         74.9 ms |      150.3 ms |
| Fresh content median           | 1,214 ms | 1,213 ms |        1,387 ms |      1,318 ms |
| Restored content median        |   663 ms |   667 ms |        1,364 ms |        770 ms |
| Restored realtime-live median  |   863 ms |   857 ms |        1,877 ms |      1,065 ms |

The second retained run had higher system load (4.8 at launch, versus 2.0 in the before run) and
slower startup. A contemporaneous observation reported a load average of 4.7, about 1.2 GiB of swap
in use and no recorded thermal/performance warning. These observations do not establish the cause
of the startup change. The later control was also noisy: its timed search HTTP p95 reached 371 ms.
Do not use that control's outliers to inflate the speedup ratio. The first before/retained comparison
and the alternating SQL diagnostic below provide cleaner evidence of the search improvement.
The slower startup samples remain in the report; this change does not establish the restored-startup
target under those conditions.

The legacy driver series includes polling delay and remains above its original 100 ms budget.
The renderer-clock series records result insertion and animation frames. Neither series establishes
physical foreground presentation. The second retained run's first-row p95 and two-frame p95 both
meet the 100 ms renderer planning target, but 20 samples do not establish a production tail SLA.

The [small-workspace run](improved-2026-09-06/search-snapshot-small.json) used five channels,
three startup pairs and 20 interactions. Search IPC was 3.0 ms median and 3.3 ms p95; result rows
were 9.6 ms p95 and the two-frame checkpoint was 28.2 ms p95. Fresh/restored content medians were
639/546 ms. This provides a small-workspace check, not a matched before/after speedup claim.

![Search after the retained large repeat](../screenshots/performance-search-snapshot.png)

The real Electron search dialog after the timed loop, captured and visually inspected. The fixture
contains synthetic messages only. The renderer was unchanged by this search implementation.

## Why the query changed

The preceding narrow-sort query already fetched bodies only after limiting the ranked page. Its
conversation-access CTE kept the ranking plan serial. On the larger fixture, ranking 200,000
common-term matches dominated elapsed query time.

A [ranking-stage diagnostic](improved-2026-09-06/search-ranking-diagnostic.json) tried calculating
ranks in a separate CTE. It did not help. Materializing those ranks had a 170.9 ms median and wrote
1,318 temporary blocks, versus 150.0 ms for its control. The unmaterialized variant took 151.1 ms.
No change from those shapes was retained.

An [alternating diagnostic](improved-2026-09-06/search-snapshot-diagnostic.json) compared the
single statement with a transaction containing access resolution and ranking. Five measured pairs
after one excluded pair took about 141 ms for the control and 62 ms for the transaction. Transaction
timing includes BEGIN, the visibility query, ranking and COMMIT. All first-page IDs and rank strings
matched. The retained shape produced a Gather Merge with two workers and no temporary spill.
The diagnostic contained an unused-identity type predicate; production reindexes its seven
parameters cleanly and contains no such predicate.

The implementation uses the repository's existing transaction helper with `isolationLevel:
"repeatable_read"` and `readOnly: true`. It applies the unchanged visibility helper and group-direct
capability gate while collecting IDs. The rank query filters by workspace and those IDs, preserves
retraction filtering, rank/sequence/ID ordering and cursor comparisons, then fetches the page's bodies.

Both queries see the snapshot established by the visibility read. A membership revocation or
retraction committed afterward cannot make the rank query mix old access with new message contents.
The next search establishes a new snapshot and sees the committed changes. No results are cached
across requests. Errors continue through the existing rollback/release helper.

The benchmark's `--explain-search` capture now selects the ranking statement by its `search_page`
CTE. COMMIT can no longer replace the captured SQL. With this implementation, captured SQL execution
time covers ranking and page-body lookup only; the timed IPC and HTTP measurements include access
resolution and transaction overhead. Do not equate the captured rank-plan time with full search latency.

## Concurrent requests and worker availability

The [load probe](improved-2026-09-06/search-snapshot-load.json) called the actual repository entrypoint
against the completed large fixture. It used the same synthetic identity and query, a pool of ten
connections and five batches after one excluded warmup batch. Every result page matched the original
query's first 25 IDs and retained a pagination cursor. These are repository timings, excluding HTTP,
Electron and UI work; they are not a comparison against the old repository under concurrent load.

| Concurrent requests | Worker configuration                      | Operations measured | Repository p95 |
| ------------------- | ----------------------------------------- | ------------------: | -------------: |
| 1                   | Default                                   |                   5 |        74.1 ms |
| 4                   | Default                                   |                  20 |       206.4 ms |
| 8                   | Default                                   |                  40 |       397.8 ms |
| 1                   | Disabled for these diagnostic connections |                   5 |       132.4 ms |

Parallel workers improve single-request latency; they do not remove total ranking work. Disabling
workers for the diagnostic connections returned latency close to the old serial query. This setting
was not applied to production or persisted in PostgreSQL. The concurrent probe does not establish a
speedup over the old query under load or emulate a remote database. Accessible-ID arrays and snapshot
duration also grow with workload; more than 200 accessible conversations remains unmeasured.

## Verification and reproduction

The real PostgreSQL suite passed all 425 server tests. The new deterministic regression revokes a
member, retracts the old matching message and sends a new private message after the search's
visibility read. The in-flight search returns only the original message from its snapshot. The next
member search is empty, while the owner sees the new message. Existing rank ties, paging, private
conversations, retractions, group capability and bot/agent access tests remain in the full suite.

`npm run check` completed with exit 0: formatting, lint, typecheck and builds passed, as did 1,898
desktop, 194 default server, 145 CLI and 150 contracts tests. Its 231 opt-in server skips are covered
by the separate PostgreSQL run. The script suite passed 186 tests and skipped one optional Docker
check. Logs are `.dev-data/performance/search-snapshot-postgres-tests.log` and
`.dev-data/performance/check-search-snapshot.log`.

Reproduce the retained native workload with:

```sh
npm run perf:baseline -- --channels=200 --messages=1000 --samples=3 --iterations=20 \
  --restore-cache=all --explain-search=true --label=search-snapshot-large
```

Raw diagnostic source remains under `.dev-data/performance/compare-search-ranking.mjs`,
`compare-search-snapshot.mjs` and `search-snapshot-load.mjs`. The control wrapper is
`.dev-data/performance/run-search-snapshot-control.mjs`, and the preserved candidate repository
source is under `.dev-data/performance/search-snapshot-candidate/`.

## Stopping checkpoint

The candidate repository source was restored byte-for-byte after the later control. The full check
ran on that restored candidate. No native benchmarks remain running, and their isolated database
clusters have been stopped. The change remains local and uncommitted.

A subsequent [foreground pilot](improved-2026-09-06/visible-snapshot-pilot-failed.json) failed before
workspace readiness or any timing samples. The guard observed a shown 1280×800 native window with
`focused: false`, while the renderer reported visible content and DOM focus. The pilot correctly
rejected that inconsistent foreground state. This does not establish that the Mac was still locked,
that visible mode works, or that normal read tracking succeeds. Further foreground work is deferred
at the user's requested stopping point. Packaged performance, long-history first visits and broader
workloads remain open.

Independent review by gpt-5.6-terra confirmed the source restoration, evidence copies, measured
values and stated limitations. No blocking correctness or reporting findings remained at this
checkpoint.
