# Reading position during history loading

Restoring the earlier windowing regression probe exposed two existing problems in the current
unwindowed timeline. Opening a search result, scrolling to the top and loading older messages first
replayed the old search jump. After that was fixed, the browser still left `scrollTop` at zero when
new rows were prepended, pushing the previously visible message down. The current change addresses
both problems. It does not virtualize the timeline or establish faster first visits.

## Evidence

| Native run                                                                      | Result after search, scroll to top and prepend                                       |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| [Current control](improved-2026-09-06/window-anchor-control.json)               | Failed: anchor moved −9,922.875 px toward the search result                          |
| [Search request guard](improved-2026-09-06/window-anchor-search-fix.json)       | Failed: anchor moved +4,168.625 px; scrollTop remained zero                          |
| [Combined candidate](improved-2026-09-06/prepend-anchor-read-setup-failed.json) | Passed the prepend assertion, then stopped at unsupported headless read-cursor setup |
| [Combined verified run](improved-2026-09-06/prepend-anchor-verified.json)       | Complete: anchor moved +0.125 px, within the 2 px tolerance                          |

The four runs above are five-channel runs with one startup pair, three interaction samples, a populated cache and
1,000 messages arriving while the receiver is closed. They establish behavior for this fixture;
one sample is not a latency distribution. The failed runs remain labeled failed in their raw JSON.
The third run's read-cursor setup failure was in the probe: the desktop intentionally disables that
operation for headless automation. The final runner sets the synthetic receiver's cursor through
the production repository in its newly created local database, including the read-state event.
That setup does not test HTTP authentication or visibility-driven read tracking. The product's
headless restriction remains unchanged.

The complete small run verified all 1,000 cumulative backlog bodies through the rendered timelines.
Its final cache contained 1,479 rows, including all 1,071 specifically checked IDs: the backlog,
17 rows from the first older-history action, 50 from the later prepend, two tall-message/reading
checks and two queued sends. The search target contained the viewport center line. Unread placement
showed the expected divider and following message. A queued send at the tail stayed visible; one
made while reading older messages preserved the anchor. Canonical acknowledgements drained the
outbox and shifted the reading anchor by zero pixels in both cases. The separate 81-paragraph
message check also preserved the off-tail reading position.

The [large repeat](improved-2026-09-06/prepend-anchor-large.json) also completed. It used 200
channels, five startup pairs, 20 interaction samples and five restart batches of 300 messages.
Prepending another 50 messages shifted the anchor by 0.125 px. Search, unread placement, initial
tail position and both pending/canonical send checks passed; pending and canonical anchor shifts
were zero. The final durable cache contained 11,796 rows and all 1,604 checked IDs: 1,500 backlog
messages, 50 from each older-history action, two tall-message/reading checks and two queued sends.

The large run's backlog content median was 701 ms and live-readiness median was 1,307 ms. Its first
older-history action took 356 ms to grow Design from 550 to 600 rows. In the fifth cycle, first
visits to Design and Performance 004 took 105.3 and 101.0 ms with 550 loaded rows each. These
measurements establish no first-visit speedup; the scroll fixes address reading-position correctness.

## Change

`WorkspaceRuntime` now issues a monotonically increasing request number for explicit main-timeline
search, task, attachment-source and thread-fallback jumps. The counter survives runtime stop/start.
The renderer waits until the target exists in the active chat and handles each request once.
Loading history or receiving another message does not replay the old jump. Explicitly opening the
same target again produces a new request and scrolls again.

A Load older action captures a fully visible message and its offset from the viewport. When one
message is taller than the viewport, the capture uses that partially visible message. The renderer
restores the offset during layout after history updates, then clears the anchor when loading ends.
It measures the remaining difference, so browser anchoring is not applied twice. Timeline input,
a different conversation or pane, or a new jump cancels the pending restoration. Retractions and
membership behavior are unchanged; a missing anchor is ignored.

The new UI regression fails against the previous search effect and passes with explicit requests.
It checks history growth followed by a repeated jump to the same search result. A runtime regression
covers repeated task/attachment navigation and session restart. Geometry tests cover fully visible
and tall anchors, viewport movement, browser anchoring and a removed row. A further UI test checks
that scrolling while a history request is pending cancels restoration. Full `npm run check` passed, including 1,898 desktop, 194 server, 145 CLI and 150 contracts tests,
plus script checks and workspace builds. The default run skipped 230 opt-in PostgreSQL tests and
one Docker-dependent script test. The native repeats used real local PostgreSQL; they do not
replace the skipped suite. The check exited zero; its log is
`.dev-data/performance/check-scroll-anchors.log`.

![Reading position after loading older history](../screenshots/performance-prepend-anchor.png)

The real desktop after the verified small prepend. The measured message stayed at its previous
viewport offset; the raw result records the identity and 0.125 px shift.

## Benchmark changes and remaining work

The behavior probe runs after all normal timing cycles. It tests search placement, a real prepend,
read-state-driven unread placement, initial tail positioning and queued/canonical transitions at
and away from the tail. The benchmark server can temporarily hold message writes through its local
process channel to make the pending state observable. Production routes and servers are unchanged.
Both older-history checks enumerate the entire loaded timeline before deciding which IDs are new,
so a later windowed renderer cannot pass by counting only mounted rows. Newly fetched IDs from both
checks are verified in the final durable cache.

The earlier virtual timeline's 32.375 px prepend failure is still unresolved. This checkpoint repairs
the current renderer and gives a stronger native control for a future windowing attempt. First visits
to long histories, normal visible/packaged-app measurements and broader workload evidence remain open.
