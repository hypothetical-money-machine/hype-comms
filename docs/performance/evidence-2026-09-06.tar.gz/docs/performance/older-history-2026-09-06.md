# Loading older history after a busy restart

One Load older messages action now continues through server pages that are already present in the
renderer. In the small native control, Design needed three clicks before growing from 150 to 200
messages. The candidate reached the same 200 messages in one click. The change removes repeated
user actions; it does not eliminate the underlying server requests.

## Why history overlapped

The encrypted cache can contain more history than the latest 50-message server page. After a
restart, the app restores that cache and refreshes the latest page. Its pagination cursor points
before the refreshed page, so subsequent requests can return messages already loaded from cache.
Previously, each request completed the user's action even when no additional messages appeared.

The cache can also contain disconnected pieces of history from earlier visits and message links.
Seeking directly to its oldest message would risk skipping uncached gaps. The runtime continues to
use the server's opaque cursor chain and processes every response in order.

## Behavior and limits

Opening a conversation still refreshes one page. A later Load older action fetches pages until it
adds a previously absent, retained main-timeline message or reaches the end. It persists each page
with its reactions, updates attachments and thread summaries, and retains the existing message
version, tombstone, membership and generation guards. Hidden thread replies do not count as new
main-timeline content when the server supports threads.

The existing loading indicator stays active throughout the action. Concurrent clicks share the
same operation. A network error leaves the last successfully persisted cursor available for Retry;
session retirement or membership removal prevents delayed data from being projected. Switching to
another conversation stops additional requests after the in-flight page finishes. Returning can
continue from that page's cursor.

One action is bounded to 20 pages, and repeated cursors stop the chain. If 20 advancing pages still
contain no new visible messages, the app asks the person to load older messages again. These bounds
prevent unbounded requests from malformed or unusually long overlapping histories. They do not
pretend that the beginning of history has been reached. Very deep restored histories can still
require another action, and a slow network can keep the loading indicator visible for several
requests.

Nine new runtime tests cover first-page-only opening, overlap, sparse gaps, updated reactions,
shared operations, failure/retry, cursor cycles, the page bound, thread replies, conversation changes
and session retirement. The existing membership-removal test also runs with removal during a
second overlapping page. The targeted runtime suite passed 170 tests.

## Small control and candidate

The [control](improved-2026-09-06/older-pages-control.json) and
[candidate](improved-2026-09-06/older-pages-candidate.json) each completed one fresh/restored pair,
three interaction samples and one 300-message backlog cycle, using five channels and a populated
cache. The new older-history probe runs after all normal timing cycles and traverses the complete
result. It requires every original loaded ID to remain reachable, then verifies the newly fetched
IDs in the final durable cache.

| Observation | Control | Candidate |
| --- | ---: | ---: |
| Loaded Design messages before action | 150 | 150 |
| Clicks before additional messages appeared | 3 | 1 |
| Loaded Design messages afterward | 200 | 200 |
| Automated action sequence | 121.7 ms | 108.9 ms |
| Final specifically checked durable IDs | 352 | 352 |

The action times include Playwright calls, frame waits and checks between clicks. They exclude
conversation selection, initial scrolling, final traversal and screenshots. A real person's delay
between unsuccessful clicks is absent. Each is one observation; the result supports fewer required
clicks, not a reliable latency percentile or a large elapsed-time speedup.

The small candidate preceded the additional stop-on-conversation-change guard. Its completion
establishes the overlap behavior in a settled conversation; subsequent large runs verify the final
source. No wire contract, server behavior or cache schema changed.

## Growing-history verification

The [large run](improved-2026-09-06/older-pages-large.json) and
[independent repeat](improved-2026-09-06/older-pages-repeat.json) use 200 channels, five fresh/restored
pairs, 20 interaction samples and five 300-message backlog cycles. Both include the guard that
stops further loading after conversation selection changes.

| Observation | Large run | Repeat |
| --- | ---: | ---: |
| Design messages before/after older-history action | 550 → 600 | 550 → 600 |
| Clicks before additional messages appeared | 1 | 1 |
| Automated older-history action | 818 ms | 838 ms |
| Fresh content, median | 1,225 ms | 1,223 ms |
| Populated-cache restored content, median | 672 ms | 622 ms |
| Populated-cache restored realtime live, median | 814 ms | 789 ms |
| Backlog first content, median | 666 ms | 679 ms |
| Backlog realtime live, median | 1,554 ms | 1,606 ms |
| Composer → recipient, p95 | 64.1 ms | 64.6 ms |

The roughly 0.8-second older-history action is still too slow to feel immediate. A control at this
history size was not measured with the new older-history probe, so no large-case elapsed-time
speedup is claimed. The one-click behavior is repeated native evidence. Profiling the remaining
request, cache and rendering work is a follow-up within the active performance goal.

Each run traversed all 1,500 cumulative generated backlog bodies before the final action. After the
older-history action it found all 600 Design IDs, including every previously loaded row and 50 new
older rows. The final encrypted cache contained 11,744 messages and all 1,552 specifically checked
IDs: 1,500 backlog messages, 50 older messages and the two layout-test messages. The earlier
11,694-message final cache lacked the new older-history probe; that count difference is additional
verified history, not cache growth from an otherwise identical measurement sequence.

The existing tall-message check passed in both runs: all 81 expected paragraphs rendered, the tail
remained attached, and a further incoming message moved the reading anchor by zero pixels. These
checks do not measure anchoring during a prepend or validate normal visible read tracking. The
new older-history probe compares row identities and durable storage; it does not compare the exact
body of every newly fetched seeded row. The runtime tests compare complete message values, and the
native screenshot shows the newly loaded synthetic Markdown rows.

![Design after one action loaded earlier history](../screenshots/performance-older-history.png)

This screenshot was captured from the first large run and visually inspected. Design now starts
with synthetic item 101, and the older-history action remains available. The renderer, database,
cache and user accounts are the isolated benchmark's synthetic environment. These unpackaged,
hidden-window macOS measurements do not establish a packaged release or other-platform timing.

Reproduce sequentially with the [runner environment](README.md):

```sh
npm run perf:baseline -- --label=older-pages-repeat --channels=200 --samples=5 \
  --iterations=20 --restore-cache=all --backlog=300
```

The final source passed `npm run check`, including formatting, lint, typechecking, workspace
builds, 1,885 desktop tests, 194 default server tests, 145 CLI tests, 150 contract tests and
186 script tests. The normal suite skips 230 opt-in PostgreSQL tests and one optional Docker test;
the native runs separately exercised real PostgreSQL. The check log is
`.dev-data/performance/check-older-pages.log`.

After the large runs, the cyclic-page error was reworded to explain the repeated page without
exposing the internal cursor terminology. A [final small smoke run](improved-2026-09-06/older-pages-final.json)
then completed on the final source and again loaded 150 → 200 Design messages in one action.
All current benchmark script and lockfile hashes match that final artifact. No package, commit or
pull request was produced in this checkpoint. The broader performance goal remains active.
