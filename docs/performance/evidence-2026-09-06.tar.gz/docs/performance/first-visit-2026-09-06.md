# First visits to long histories

After scoped startup catch-up, first visits to unopened 550-message histories took 106–117 ms.
The new per-visit profile points to initial DOM rendering as a larger cost than the IndexedDB
read itself. Grouping each conversation into one keyed DOM subtree did not improve the matched native
comparison. That experiment was removed. The per-visit measurements remain available for future
work; first visits to long histories still need improvement.

## Profile and control

The [profile](improved-2026-09-06/first-visit-profile.json) used 200 channels, a populated cache,
five startup pairs, 20 interaction samples and five 300-message backlog cycles. Each first visit
now records renderer duration deltas and, when profiled, successful IndexedDB `getAll` observations.
The original browser-clock viewport timer is unchanged. CDP calls surround that timer and the cache
observer surrounds those calls. The intervals can include other renderer work and background reads;
script/task/read durations are not an additive breakdown of the viewport wait. See [README](README.md).

| Fifth-cycle observation       |   Design | Performance 004 |
| ----------------------------- | -------: | --------------: |
| Profiled viewport time        | 105.3 ms |        109.4 ms |
| Renderer script duration      |  42.8 ms |         40.6 ms |
| Renderer task duration        | 102.2 ms |        110.5 ms |
| Layout duration               |  19.2 ms |         19.4 ms |
| Style recalculation duration  |  11.8 ms |         10.9 ms |
| Indexed message values read   |      550 |             550 |
| Message read result delivered |   5.5 ms |          5.3 ms |
| Catalog rows read             |      201 |             201 |

Both visits also read one workspace row and two members, plus empty reactions, tasks and outbox.
Their seven observed `getAll` calls each completed during the interval. Those read timings exclude
decryption. The aggregate three-visit CPU profile sampled DOM removal, insertion and attribute/text
updates alongside React work. It sampled about 7.6 ms in `removeChild` across all three visits;
this does not attribute all layout or program time to DOM removal.

The [unprofiled control](improved-2026-09-06/first-visit-control.json) uses the same parameters and
new CDP observation calls. Its fifth visits were 104.6 ms and 96.9 ms. Script durations were
42.1/36.8 ms, layout 19.0/19.7 ms, style 9.7/8.9 ms and task 103.5/96.0 ms. These values establish
a matched control for the experiment; the earlier 106–117 ms values used the prior runner.
The control completed with all 1,552 specifically checked final IDs and 11,744 durable messages.

## Rejected timeline subtree experiment

The candidate gave the main timeline one `timeline-content` child keyed by the selected conversation. React can
remove that child and its descendants in one DOM operation on conversation change. Within the
same conversation, the child keeps its identity and existing message keys/memoization still apply.
Its CSS used `display: contents`, so the child contributes no layout box. The active-row selector
targeted messages inside that child, preserving their overflowing action controls.

The outer message list, scroll ref, read-tracking handler and `aria-live` region remain mounted.
The existing effects still choose unread/tail positioning on selection and keep the composer
outside the replaced subtree. No cached messages, network requests, outbox, encryption or wire
behavior changed. Full history still renders; this experiment does not virtualize rows.

The targeted app, read-tracking and memoized-row suites passed 144 tests, followed by desktop
typechecking and lint. The [native candidate](improved-2026-09-06/timeline-subtree-candidate.json)
completed with all 11,744 durable rows and 1,552 specifically checked final IDs. All 1,500 cumulative
backlog messages were verified through their conversations. Reaction controls remained clickable,
the 81-paragraph message remained readable from beginning to end, and off-tail reading shifted
by zero pixels.

| Loaded rows per unopened conversation | Control Design | Candidate Design | Control Performance 004 | Candidate Performance 004 |
| ------------------------------------- | -------------: | ---------------: | ----------------------: | ------------------------: |
| 150                                   |        60.2 ms |          62.4 ms |                 62.5 ms |                   64.8 ms |
| 250                                   |        75.7 ms |          64.6 ms |                 57.6 ms |                   69.9 ms |
| 350                                   |        76.4 ms |          77.0 ms |                 85.7 ms |                   85.1 ms |
| 450                                   |        90.8 ms |          90.9 ms |                 86.4 ms |                   85.7 ms |
| 550                                   |       104.6 ms |         105.0 ms |                 96.9 ms |                   95.6 ms |

At 550 rows, renderer task durations were 103.5/96.0 ms in the control and 102.9/95.8 ms in
the candidate. Script, layout and style durations also remained similar. This single matched
comparison provides no evidence of a worthwhile improvement. It does not prove the two versions
are equivalent across workloads. The source was restored byte-for-byte from the pre-experiment
App and CSS backups, preserving the earlier performance changes.

The candidate's restart content median was 662 ms and live median was 1,289 ms, compared with
700/1,319 ms in the control. This change targeted switching and showed no benefit there; those
startup differences do not justify retaining it. Cached switching remained 49 ms, typing-to-frame
about 33 ms, composer-to-receiver about 62 ms and the search driver about 111 ms in both runs.
These development-profile measurements do not establish packaged-app or other-platform performance.

`npm run check` passed on the restored source and retained instrumentation. The local log is
`.dev-data/performance/check-first-visit-instrumentation.log`. Independent review by gpt-5.6-terra
confirmed the raw-result copies, source restoration, comparison values and diagnostic limitations.
The fifth Design control visit remains above the 100 ms first-visit target. The broader goal
remains open.

## Rejected empty reaction lists experiment

Each reaction-free row mounted two empty reaction-list elements that CSS hid. A candidate omitted
those elements until a reaction or error existed, keeping the action buttons and picker mounted.
The existing reaction and message-row suites passed 28 tests, followed by desktop typechecking.
The [native candidate](improved-2026-09-06/empty-reactions-candidate.json) used the same runner and
200-channel, five-cycle workload as the matched control above.

The final Design/Performance 004 visits took 106.4/102.2 ms, with renderer task durations of
105.6/109.2 ms. Control values were 104.6/96.9 ms and 103.5/96.0 ms. There was no measured benefit;
the source was restored byte-for-byte from its pre-experiment backup. This single comparison does
not establish a regression either. All 11,744 durable rows and 1,552 checked IDs remained, reaction
controls passed, and the tall-message/off-tail check recorded zero reading-position shift.

Independent review by gpt-5.6-terra found no behavior or accessibility blocker. The rejection is
based on the native measurements, not a correctness failure.

## Rejected Unreads memo experiment

The first-visit CPU profile sampled `formatUnreadTime` inside the hidden Unreads page. A candidate
memoized the unread projection on the full bootstrap and runtime, and used React's default shallow
memo around `UnreadsView`. It kept the page mounted and preserved updates for navigation, counts,
member names and current-user changes. Independent gpt-5.6-terra review found no dependency or
visibility blocker. Existing Unreads, unread-projection and composer suites passed 37 tests,
followed by desktop typechecking and lint.

The [native candidate](improved-2026-09-06/unreads-memo-candidate.json) used the same runner and
200-channel, five-cycle workload as the matched control. Final Design/Performance 004 visits took
105.0/98.2 ms, compared with 104.6/96.9 ms in the control. Their renderer task durations were
104.8/104.2 ms versus 103.5/96.0 ms. Those observations do not establish a first-visit benefit.
App and Unreads source were restored byte-for-byte from their pre-experiment backups.

All 11,744 durable rows and 1,552 checked final IDs remained. Full traversal verified the cumulative
1,500 backlog bodies, reaction controls remained clickable, and the tall-message check preserved
tail following and the off-tail reading position. These passing behavior checks do not establish
a speedup. No new production change is retained from either of these two experiments.

After both restorations, `npm run check` passed. The log is
`.dev-data/performance/check-rendering-experiments-restored.log`. The ten benchmark-script hashes
and lockfile hash match the control for both candidates. Final gpt-5.6-terra review verified the
raw-result copies, source restoration and reported values. First-visit and broader workload
requirements remain open.

## Next rendering work

The matched control's renderer task duration increases from about 50–55 ms at 150 rows to
96–104 ms at 550 rows. Grouping the subtree, omitting empty reaction lists and memoizing Unreads
have not reduced that first-visit cost in their respective comparisons. The next rendering attempt
should address how many complete message rows are rendered initially. It must preserve access to
all loaded history, unread and search placement, pending-message transitions and the reading anchor
on prepend. The [earlier windowing failure](windowing-2026-09-06.md) remains a required regression
case; no claim is made that a replacement has been implemented or verified.
