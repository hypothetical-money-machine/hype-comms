# Opening history after restart catch-up

Nonempty startup catch-up reloaded every cached conversation after applying its events, undoing
the benefit of restoring only the opening history. A profiling-only IndexedDB observer confirmed
that the app reads the full 10,492–11,692-message cache before becoming live. The runtime now
keeps that reload scoped to the opening history when it is still the only conversation restored.
Two native runs reached realtime-live in 1,271 and 1,336 ms median, while later first visits
to long histories became slower. Those visits remain above the 100 ms target.

## Measured cache reads

The [profiled control](improved-2026-09-06/catchup-cache-profile.json) uses 200 channels, a fully
populated cache, five startup pairs, 20 interactions and five 300-message backlog cycles. The
observer installs after the first Electron window and profiler initialization and captures at
realtime-live. It observes successful `getAll` requests on IndexedDB stores and indexes, keeping
names, row counts and timings without retaining values. Every cycle completed all 318 observed
requests before capture. This excludes earlier startup and all `get`, cursor, key and count reads.
See [README](README.md) for the clocks and observer boundaries.

| Backlog cycle | Opening-history rows read | Later full-table rows read | Full-table result delivered |
| ------------- | ------------------------: | -------------------------: | --------------------------: |
| 1             |                       242 |                     10,492 |                     44.4 ms |
| 2             |                       342 |                     10,792 |                     41.3 ms |
| 3             |                       442 |                     11,092 |                     38.6 ms |
| 4             |                       542 |                     11,392 |                     41.3 ms |
| 5             |                       642 |                     11,692 |                     54.9 ms |

These read durations include event-loop scheduling and delivery to the observer. The observer's
listener is installed before the caller adds its handler, so it can run before application
processing. These timings exclude the subsequent decryption and are not additive across concurrent
reads. The profile also showed 303 reads of the one-row workspace store in each cycle: three cache
loads and one per applied message event. That repeated metadata read remains unchanged.

The unprofiled [retention control and candidates](retention-2026-09-06.md) are the latency references.
Their catch-up differences were smaller and inconclusive, while removing the retention preflight in
a reverse-order control restored the roughly 0.84-second older-history wait. This investigation
retains indexed retention and targets the separate reload cost. Profiled elapsed times must not be
used as speedup estimates.

## Change and safeguards

The runtime can request an opening-conversation reload only during initial cached startup. The
selected conversation must be the sole history restored into memory, with no other conversation's
messages, tasks or thread summaries and no attachment or conversation-file state. Other states
keep the full reload. The runtime checks this condition again after the asynchronous read; navigation
that changed the projection falls back to a full reload.

The cache's existing scoped read still returns the whole catalog, current members, durable cursor,
retract reservations and outbox. Catch-up continues applying every event to the durable cache,
advancing and acknowledging cursors in the same order. Unopened histories remain available through
the existing guarded first-visit cache load. The runtime marks only the opening conversation as
restored, so a later visit cannot mistake an unloaded history for an already restored one.

Resets, membership repairs, resyncs and applied source-less retractions keep the full reload.
The latter preserves thread-summary and unread-counter reconciliation when the renderer did not
have the deleted message's source. Full snapshot and metadata-repair callers are unchanged. No cache
schema, encryption, wire, authorization or retention policy changed.

Four runtime tests cover durable catch-up followed by lazy restoration of another conversation's
old/new messages, reactions and tasks; concurrent navigation during the scoped read; session
retirement; and a source-less retraction in an unopened history. All 174 runtime tests passed.
Typechecking initially rejected the new fixture's spread of a union-typed event. Giving it an
explicit `message.created` discriminator fixed the fixture without changing runtime behavior.
Desktop typechecking and lint subsequently passed. Native evidence follows. This is not a completion claim for the performance goal.

## Native results

The [candidate](improved-2026-09-06/startup-scoped-reload-candidate.json) and
[independent repeat](improved-2026-09-06/startup-scoped-reload-repeat.json) use the same unprofiled
200-channel, five-cycle workload and 20 interaction samples as the two preceding indexed-retention
runs. The new IndexedDB observer is disabled in these measurements. Each backlog cycle adds 100
messages per measured conversation; the visit values below are individual first visits after the
fifth restart, not percentiles for repeated cached navigation.

| Observation                            | Retention candidate | Retention repeat | Scoped candidate | Scoped repeat |
| -------------------------------------- | ------------------: | ---------------: | ---------------: | ------------: |
| Backlog content, median                |              667 ms |           714 ms |           665 ms |        737 ms |
| Backlog realtime live, median          |            1,547 ms |         1,611 ms |         1,271 ms |      1,336 ms |
| Fifth Design visit                     |             72.4 ms |          84.3 ms |         106.2 ms |      108.2 ms |
| Fifth Performance 004 visit            |             65.2 ms |          72.5 ms |         107.5 ms |      117.1 ms |
| Older-history action                   |              342 ms |           333 ms |           325 ms |        328 ms |
| Final specifically checked durable IDs |               1,552 |            1,552 |            1,552 |         1,552 |

Realtime-live is 211–340 ms earlier across these runs, a 14–21% reduction against the two retention
runs. First content does not show a clear gain. Its 665/737 ms medians meet the 750 ms budget,
but the final repeat cycle takes 763 ms, so this is not a guarantee on every start. Deferring
unopened histories moves their read/decryption work into first visits: both candidates' two final
visits exceed the 100 ms planning target. Repeated cached switching remains at 49.2/51.1 ms p95. The faster catch-up does not establish completion of the
conversation-switching goal. Reducing first-visit cache work remains necessary.

All five cycles in each run verified their cumulative backlog bodies. Each final cache contained
11,744 messages and all 1,552 specifically checked IDs. The native tall-message check rendered all 81 paragraphs,
retained the tail and recorded zero reading-anchor movement during an off-tail append. These are
unpackaged, hidden-window macOS measurements with synthetic users and messages. They do not prove
visible read tracking, prepend anchoring, packaged performance, or other-platform behavior.

![Design after catch-up, first visit and older-history loading](../screenshots/performance-startup-scoped-reload.png)

This screenshot is from the completed native candidate and was visually inspected.

## Confirming the reduced read

The [post-change profile](improved-2026-09-06/startup-scoped-reload-profile.json) repeats one
200-channel startup pair and one 300-message backlog cycle with the same 20 interaction samples.
It observes 242 opening-history rows at initial restore, followed by 342 opening-history rows at
reload, with no messages-store full-table `getAll`. The corresponding first control cycle read
242 opening rows followed by all 10,492 messages. The reload therefore fetches 96.7% fewer message
values. The complete cache still contains 10,492 messages and all 300 backlog IDs at live readiness.

All 318 observed reads completed in the profile. The scoped reload result arrived in 3.7 ms versus
44.4 ms for the first control's full-table result, before decryption. Those are individual profiled
read observations, not an elapsed startup speedup. The unprofiled five-cycle runs above establish
the latency comparison. Later traversal and layout/older-history checks verified all 300 generated
bodies and 352 specifically checked final IDs, leaving 10,544 durable messages. The profile's
smaller final count reflects its one backlog cycle, not missing messages from the five-cycle run.

Reproduce sequentially with the environment in [README](README.md):

```sh
npm run perf:baseline -- --label=startup-scoped-reload-repeat --channels=200 --samples=5 \
  --iterations=20 --restore-cache=all --backlog=300
npm run perf:baseline -- --label=startup-scoped-reload-profile --channels=200 --samples=1 \
  --iterations=20 --restore-cache=all --backlog=300 --profile=true
```

## Verification

The final `npm run check` exited successfully, covering formatting, lint, typechecking, workspace
builds, 1,892 desktop tests, 194 default server tests, 145 CLI tests, 150 contract tests, 186 script
tests and 113 Hermes plugin tests. The default suite skips 230 opt-in PostgreSQL tests and one
optional Docker test; the native runs separately used real PostgreSQL. The log is
`.dev-data/performance/check-startup-scoped-reload.log`. The independent `gpt-5.6-terra` review
verified the copies, recorded hashes, read counts, check log and decision trail. Its attention item
is the deferred first-visit delay and the final 763 ms content sample; both are recorded above.

The first-visit regression remains open. The retained change makes restart catch-up earlier but
does not complete the goal of moving between busy conversations without waiting. The original
baseline files remain unchanged. No package, commit or pull request was produced.
