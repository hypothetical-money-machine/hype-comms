# Windowing investigation

The virtual timeline experiment was rejected. It reduced the number of mounted rows, but loading
older history moved the reading position by 32.375 CSS pixels. Small pilot startup also became
slower. The branch retains the preceding row memoization, cache, startup and query improvements.
Every loaded main-timeline message remains mounted.

The goal remains to make a busy Hype Comms workspace feel as fast as a small one: open it quickly,
see new messages promptly, and move between conversations without waiting. The original
[baseline and planning targets](baseline-2026-09-06.md#proposed-branch-targets) remain unchanged.
This investigation does not establish another performance improvement.

## Pilot results

The [small control](improved-2026-09-06/window-control-pilot.json) and
[first candidate](improved-2026-09-06/window-candidate-pilot.json) each use five channels, one
fresh/restored pair, three interaction samples and 1,000 messages received during one closed-app
interval. Both runs completed the checks present at that time. These single observations cannot
establish reliable latency tails or a repeatable speedup.

| Observation | Control | Windowed pilot |
| --- | ---: | ---: |
| Fresh content | 617 ms | 795 ms |
| Restored content | 540 ms | 717 ms |
| Backlog first content | 630 ms | 830 ms |
| Backlog realtime live | 1,998 ms | 1,865 ms |
| General first viewport, 542 loaded messages | 32.6 ms | 43.9 ms |
| Design first viewport, 383 loaded messages | 58.9 ms | 41.3 ms |
| Performance 004 first viewport, 333 loaded messages | 39.6 ms | 41.1 ms |

The candidate mounted 48 rows in each measured middle viewport. Complete traversal still found
all loaded IDs and verified all 1,000 generated backlog bodies. This establishes that the sampled
histories were reachable, not that all scrolling behavior was correct. The candidate still kept
pending sends in a footer; that design was replaced with pending rows in the virtualized data,
because footer growth does not reliably trigger the library's tail-follow behavior.

## Why the experiment was removed

The later native probe searched for a message outside the mounted window, opened it, scrolled to
the beginning, and loaded older history. Restored cache pages can overlap the server history cursor,
so the probe clicked through overlapping pages until the loaded count grew. It then compared the
same fully visible message's vertical position before and after the prepend.

The [failed retry](improved-2026-09-06/window-behavior-failed.json) exited with
`Older history moved the reading anchor: 32.375`. Its failure geometry records 200 loaded messages,
15 mounted messages, and a 582-pixel viewport. The virtual item combined a date separator, unread
divider and message row. Prepending history can change the old first item's height and grouping;
matching item indices alone did not preserve the reading position. The precise contribution of
each height change was not isolated before rejection.

A preceding probe also rejected a visible search result for a 3.9-pixel center error. That assertion
was too strict for a 27-pixel row. It was changed to require the viewport center line to fall inside
the highlighted row, while retaining the measured error. Search placement passed on the failed
prepend retry. This correction did not change production scrolling.

Two component tests initially failed because happy-dom reported a zero-height native scroller
after the library applied its mock viewport. Consistent native viewport dimensions made the tests
pass. Forty targeted tests, desktop typechecking and targeted lint passed before the final native
failure. They did not prove native scroll correctness. The experimental component, tests,
read-tracking extension, dependency and CSS were removed together. The preceding App, desktop
manifest and lockfile were restored from byte-checked backups.

The failed run stopped before unread-entry, initial-tail and queued-send assertions. None of those
checks is claimed as passing. The experimental source, probe, tests and failure screenshots remain
in the ignored `.dev-data/performance/rejected-windowing/` and timestamped run directories. A future
windowing attempt needs native proof of stable prepends, unread placement, search jumps, empty
conversations, pending/canonical transitions both at and away from the tail, and simultaneous
prepend/removal. It also needs repeated startup and long-history comparisons before acceptance.

## Measurement changes retained

The active runner keeps the new `scripts/performance-timeline.mjs` helper. Each backlog cycle now
times all three first viewports before traversing every loaded history. `visits[].viewportMs`
requires a visible row belonging to the selected conversation and then two animation frames.
`visits[].traversal` separately records every distinct rendered ID and verifies all cumulative
generated backlog bodies. It requires the distinct ID count to equal the loaded count, but does
not compare the exact body of every original seeded message.

The earlier `visits[].ms` waited for all expected bodies before completing. Its numbers cannot be
substituted into this first-viewport series. Typing now runs after traversal at the tail; earlier
typing results used a different scroll position. Startup now requires the authenticated General
header and a canonical row instead of seeded General text. These boundaries are documented in the
[runner reference](README.md). The original baseline report and four original raw files were not
rewritten.

Each cycle checks every cumulative backlog ID in persistent storage. The final close rereads all
1,500 backlog IDs and the two messages added by the post-timing tall-message and reading-position
checks. The failed experimental behavior probe and its server write hold were removed from the
active runner; they are retained locally for diagnosis. Removing them does not establish that the
preceding timeline passes those additional checks.

## Retained application verification

The [large control](improved-2026-09-06/window-control.json) and
[retained repeat](improved-2026-09-06/window-rejected-retained.json) each completed five startup pairs,
20 interaction samples and five 300-message backlog cycles, with 200 channels and a populated
cache. Both use the new viewport/traversal sequence. The repeat additionally rereads all cumulative
backlog IDs plus both post-timing message IDs before final close.

| Observation | Large control | Retained repeat |
| --- | ---: | ---: |
| Backlog first content, median | 696 ms | 701 ms |
| Backlog realtime live, median | 1,563 ms | 1,538 ms |
| Fifth Design first viewport, 550 messages | 91.3 ms | 89.7 ms |
| Fifth Performance 004 first viewport, 550 messages | 66.3 ms | 96.4 ms |
| Final-cycle typing script time, 20 inputs | 99 ms | 103 ms |
| Final-cycle typing through two frames, p95 | 33.9 ms | 34.9 ms |

These results confirm the restored source and show variability in first-viewport timing. They do
not replace the preceding row-memo report's 112 ms full-history visit with a claimed 89.7 ms
optimization. The repeat's normal fresh content median is 1,228 ms; populated-cache restored
content is 663 ms and restored realtime live is 815 ms. Composer-to-recipient p95 is 78.4 ms.
Search's original driver measurement remains above its 100 ms target at 113.8 ms p95.

The final repeat traversed 742 General, 550 Design and 550 Performance 004 messages. All three
matched their distinct rendered-ID counts, and the traversal checked all 1,500 cumulative backlog
bodies. Final storage retained 11,694 messages, including all 1,502 specifically checked IDs.
Reaction actions remained clickable, the reaction picker restored keyboard focus, and the
81-paragraph message rendered all expected text. Its tail gap was -1 CSS pixel; another incoming
message moved the reading anchor by zero pixels. This is the retained tall-message append check,
not a passing rerun of the rejected prepend probe.

![Retained timeline after full-history traversal and typing](../screenshots/performance-windowing-retained.png)

This screenshot was captured from the retained repeat and visually inspected. It shows Performance
004 at the tail with the 21-character verified draft. The run used production-built, unpackaged,
hidden Electron and isolated local PostgreSQL on the reference macOS arm64 machine. It does not
establish normal visible read tracking, physical presentation latency, packaged-app performance,
server concurrency, richer conversation workloads or memory/CPU soak behavior.

Reproduce the retained suite sequentially with the [runner environment](README.md):

```sh
npm run perf:baseline -- --label=window-rejected-retained --channels=200 --samples=5 \
  --iterations=20 --restore-cache=all --backlog=300
```

The retained source passed `npm run check`: formatting, lint, typechecking, workspace builds,
1,875 desktop tests, 194 default server tests, 145 CLI tests, 150 contract tests and 186 script
tests. The normal check skips 230 opt-in PostgreSQL tests and one optional Docker script test;
the benchmark separately exercised real PostgreSQL. The check log is
`.dev-data/performance/check-window-rejected-retained.log`. No package or release was produced.
